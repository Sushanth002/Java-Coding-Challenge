module assignment {
	requires java.sql;
}