package exceptions;

public class AdoptionException extends Exception{
	public AdoptionException(String text) {
        super(text);
    }

}
